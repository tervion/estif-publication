# estif_ec_gr_model.py

"""
Emergent Spacetime from Inward Flow (ESTIF)

v6.4.1 status (July 2026): this module is the frozen v6.2 analytical suite,
computationally unchanged, kept as a runnable receipt (21/21 via
estif_ec_gr_run_simulation.py). The claim status of what it computes has
moved since v6.2:
  - Ω_tilt(z) cosmology (Option A): RETIRED as a cosmology claim (v6.3,
    Task 6). Honest cosmology = imported cosmological constant, w = −1
    (RHAC-004). The functions below remain as historical receipts.
  - Ωm = x₀: consistency relation, not a prediction (C2; final per RHAC-009).
  - a₀ = H₀cx₀/√3: a₀ is horizon-set (a₀ ≈ c·H); the √3 prefactor is a
    working form, NOT derived (doctrine of 13 Jul 2026). Value unchanged.
  - Strong-field tilt (EHT / Λ / LISA): consistent; deviation-from-GR claims
    conditional on the un-derived eddy-stress sector (C1).

Core Principles as written in v6.2 (historical):
1. ΛCDM matter sector retained (Ωm, radiation)
2. Dark energy (ΩΛ) replaced by tilt geometry: Ω_tilt(z)
3. Combined formula calibrated to EHT, Planck Λ, and LISA simultaneously
4. Three project goals confirmed analytically:
   - Goal 1: Gravity = Time = Eddies (β=τ at n=½, ω²=H₀²x at crossover)
   - Goal 2: Expansion = 4D inward fall (Option A dark energy, 6 tests pass)
   - Goal 3: No dark matter — Ωm=x₀ (0.12%), a₀=H₀cx₀/√3 (1.72% MOND)

The tilt formula at three scales:
    Observable(r) = √β(x_local) × √β(x_galactic) × √β(x_cosmic)

At Earth: local=1.000, galactic=1.000, cosmic=0.830 (dark matter dominates 10⁶×)
"""

import numpy as np
from scipy.optimize import fsolve, brentq
from scipy.integrate import quad
import sys
import estif_ec_gr_constants as const

# ============================================================================
# ΛCDM COSMOLOGY (Standard Model - No Modifications)
# ============================================================================
from astropy.cosmology import FlatLambdaCDM

_cosmo_lcdm = FlatLambdaCDM(H0=67.66, Om0=0.3111)  # Planck 2018 parameters

def luminosity_distance(z):
    """
    Standard ΛCDM luminosity distance.
    
    Args:
        z: Redshift (scalar or array)
    
    Returns:
        Luminosity distance in Mpc
    """
    return _cosmo_lcdm.luminosity_distance(z).to_value('Mpc')

def scale_factor_lcdm(z):
    """
    Standard ΛCDM scale factor a(z) = 1/(1+z).
    
    Args:
        z: Redshift (scalar or array)
    
    Returns:
        Scale factor (dimensionless)
    """
    return 1.0 / (1.0 + z)

def comoving_distance(z):
    """
    Standard ΛCDM comoving distance.
    
    Args:
        z: Redshift (scalar or array)
    
    Returns:
        Comoving distance in Mpc
    """
    return _cosmo_lcdm.comoving_distance(z).to_value('Mpc')

# ============================================================================
# End ΛCDM Section
# ============================================================================

sys.setrecursionlimit(5000)

EPS = 1e-12  # Numerical stability epsilon

# ============================================================================
# COMBINED FORMULA (v6.0 — March 2026)
# Jointly calibrated to satisfy EHT M87* shadow, Planck Λ, and LISA GW
# simultaneously. Three independent observations, one formula, zero free
# parameters after calibration.
#
# n(x) = 33.265 × exp(-15.429 × x)   ← dynamic tilt exponent
# β(x) = √(1 - x^(2n(x)))            ← tilt suppression
# Observable = √β(x)                  ← square root projection
#
# where x = curvature ratio:
#   local:         x = Rs / r
#   cosmological:  x = R_H / r_universe  (= x₀ ≈ Ωm at z=0)
#
# THREE IDENTITIES at x = 0.272 (n = ½):
#   β(x) = τ(x) = √(1-x)           — GR time dilation = ESTIF tilt
#   (ω/H₀)² = x                    — eddy spin = curvature
#   a = −c² × ∇(ω/H₀)²/2 = GM/r² — gravity = gradient of eddy spin
#
# MULTI-SCALE OBSERVABLE:
#   Observable(r) = √β(x_local) × √β(x_galactic) × √β(x_cosmic)
#   x_cosmic = x₀ = R_H/r_universe ≈ Ωm (dark matter = cosmic eddy)
#
# See: tests/test_joint_calibration.py, tests/test_gravity_time_connection.py
#      tests/test_eddy_time_gravity.py, tests/test_eddy_dark_matter.py
# ============================================================================

# Calibrated parameters (do not modify without re-running test_joint_calibration.py)
N_MAX_COMBINED = 33.265   # tilt exponent in flat space
B_COMBINED     = 15.429   # exponential decay rate


def n_dynamic(curvature):
    """
    Dynamic tilt exponent from H4 (bounded exponential form).

    n varies with local curvature — exactly as gravitational acceleration g
    varies planet to planet in Newton's formula. The tilt formula is
    universal; what changes is the environment-dependent input n.

    n(x) = N_MAX × exp(-B × x)

    Limits:
        x → 0 (flat space):  n → 33.265  (maximum lean available)
        x = 0.272:           n = 0.500   (GR time dilation crossover)
        x = 0.667 (M87*):    n ≈ 0.001   (almost fully suppressed)
        x → 1 (horizon):     n → 0       (complete suppression)

    Args:
        curvature: x = Rs/r (local) or R_H/r_universe (cosmological)

    Returns:
        Dynamic tilt exponent n (dimensionless)
    """
    return N_MAX_COMBINED * np.exp(-B_COMBINED * np.asarray(curvature))


def beta_combined(curvature):
    """
    Tilt suppression factor from combined formula.

    β(x) = cos(θ) = √(1 - x^(2n(x)))

    This is the fraction of the 4D correction that remains visible
    in 3D. It generalizes the Schwarzschild time dilation factor:
    when n = ½ (at x = 0.272), β(x) = √(1-x) = τ_GR exactly.

    Args:
        curvature: x = Rs/r (local) or R_H/r_universe (cosmological)

    Returns:
        Suppression factor β (dimensionless, 0 to 1)
    """
    x   = np.asarray(curvature, dtype=float)
    n   = n_dynamic(x)
    val = np.where(x > 0, x ** (2.0 * n), 0.0)
    return np.where(val >= 1.0, 0.0, np.sqrt(np.maximum(0.0, 1.0 - val)))


def observable_combined(curvature):
    """
    3D observable from combined formula: √β(x)

    The 3D measurement captures the square root of the 4D amplitude.
    This follows from wave physics: intensity ∝ amplitude², so the
    observable amplitude is √(energy correction) = √β.

    At the GR crossover (x = 0.272, n = ½):
        observable = √β = τ_GR^(1/4) = (1-x)^(1/4)
    which connects to black hole thermodynamics through the
    Stefan-Boltzmann fourth-root relationship.

    Args:
        curvature: x = Rs/r (local) or R_H/r_universe (cosmological)

    Returns:
        Observable correction factor (dimensionless, 0 to 1)
    """
    return np.sqrt(beta_combined(curvature))

# ============================================================================
# End Combined Formula Section
# ============================================================================

# ------------------------------
# Friction Functions (Core Predictions)
# ------------------------------

def friction_drag(t, mass=1.0, beta_drag=None):
    """
    Cosmic-average drag for reference only.
    
    NOTE: For ESTIF-Gravity predictions, use friction_drag_local() instead.
    This function kept for weak-field compatibility checks only.
    
    Args:
        t: Cosmic time in seconds
        mass: Mass scaling factor (default 1.0)
        beta_drag: Override for BETA_DRAG constant (uses const.BETA_DRAG if None)
    
    Returns:
        Cosmic drag coefficient
    """
    if beta_drag is None:
        beta_drag = const.BETA_DRAG
    
    # Cosmic density proxy: ρ ~ 1/t²
    rho_approx = 1 / (t**2 + EPS)
    return beta_drag * mass * rho_approx


def friction_drag_local(M, r, beta_drag=None):
    """
    🎯 CORE PREDICTION: Local drag from mass density near massive objects.
    
    This is THE key function for ESTIF-Gravity predictions.
    Use for: black hole lensing, GW mergers, galaxy rotation.
    
    Physics: Friction creates "eddies" in 4D flow proportional to local density.
    
    Args:
        M: Mass of object creating the eddy (kg)
        r: Radius of region (m) - typically distance from object
        beta_drag: Override for BETA_DRAG constant (uses const.BETA_DRAG if None)
    
    Returns:
        Local drag coefficient based on actual mass density
        
    Example:
        For M87* black hole at r = 5*R_s:
        drag = friction_drag_local(6.5e9*M_sun, 5*schwarzschild_radius(6.5e9*M_sun))
    """
    if beta_drag is None:
        beta_drag = const.BETA_DRAG
    
    # Local mass density in spherical region
    volume = (4.0/3.0) * np.pi * (r**3)
    rho_local = M / volume
    
    # Drag scales with local density
    return beta_drag * rho_local
    
def beta_tilt(r, M, n=0.05):
    """
    Geometric suppression factor from 4D hypersurface tilt.
    
    sin(θ) = (Rs/r)^n  →  β(r) = cos(θ) = √(1 - (Rs/r)^(2n))
    
    EHT-constrained range: n = 0.05 – 0.215
    Default n = 0.05 (best fit to EHT M87* observation).
    """
    rs = 2 * const.G * M / const.c**2
    ratio = (rs / r) ** (2 * n)
    if np.isscalar(ratio):
        return 0.0 if ratio >= 1.0 else np.sqrt(1.0 - ratio)
    return np.where(ratio >= 1.0, 0.0, np.sqrt(np.maximum(0.0, 1.0 - ratio)))


# ============================================================================
# ⚠️ DEPRECATED: Exponential Cosmology Functions
# ============================================================================
# The functions below implement S(t) = exp(-∫H dt) which attempted to explain
# cosmic expansion via 4D inward flow. This was ruled out by supernova data
# (χ² = 3.8× worse than ΛCDM in fair comparison with M_offset).
#
# ESTIF-Gravity fork uses standard ΛCDM (functions at top) for cosmology.
#
# These are kept commented out for:
# 1. Historical reference
# 2. Comparison with original ESTIF-FD implementation
# 3. Understanding what was tested and ruled out
# ============================================================================

'''
def H_approx(t, H0=const.H_0, A=const.A_DEFAULT):
    """
    DEPRECATED - Approximate H(t) for scale factor calculation.
    Use ΛCDM functions instead.
    """
    t = np.asarray(t)
    early_term = (A * 0.01) / (t**1.5 + EPS)
    return H0 + early_term


def H_variable(t, H0=None, A=None, beta_drag=None):
    """
    DEPRECATED - Variable flow rate H(t).
    Use astropy.cosmology.FlatLambdaCDM instead.
    """
    if H0 is None:
        H0 = const.H_0
    if A is None:
        A = const.A_DEFAULT
    if beta_drag is None:
        beta_drag = const.BETA_DRAG
    
    t = np.asarray(t)
    
    t_floor = 1e10
    t_safe = np.maximum(t, t_floor)
    early_term = A / (t_safe**0.75 + EPS)
    
    drag = beta_drag / (t**2 + EPS)
    drag_term = drag * (const.G / const.c**2)
    illusion_term = beta_drag / ((t / 1e17)**2 + EPS) * 1e-20
    
    return H0 + early_term + drag_term + illusion_term


def global_S(t, n_steps=1000, H0=None, A=None, beta_drag=None):
    """
    DEPRECATED - Exponential shrinkage S(t) = exp(-∫H dt).
    Use scale_factor_lcdm(z) = 1/(1+z) instead.
    """
    if H0 is None:
        H0 = const.H_0
    if A is None:
        A = const.A_DEFAULT
    if beta_drag is None:
        beta_drag = const.BETA_DRAG
    
    t = np.asarray(t)
    scalar_input = t.ndim == 0
    t = np.atleast_1d(t)
    result = np.zeros_like(t, dtype=float)
    
    for i, ti in enumerate(t):
        if ti <= EPS:
            result[i] = 1.0
            continue
        
        t_start = min(1e16, ti * 0.01)
        t_range = np.linspace(t_start, ti, n_steps + 1)
        h_vals = H_approx(t_range, H0=H0, A=A)
        integral = np.trapz(h_vals, t_range)
        
        if integral > 100:
            integral = 50
        
        result[i] = np.exp(-integral)
    
    return result[0] if scalar_input else result


def global_S_approx(t, n_steps=500, H0=None, A=None):
    """
    DEPRECATED - Approximate S(t).
    Use scale_factor_lcdm(z) instead.
    """
    if H0 is None:
        H0 = const.H_0
    if A is None:
        A = const.A_DEFAULT
    
    t = np.asarray(t)
    scalar_input = t.ndim == 0
    t = np.atleast_1d(t)
    result = np.zeros_like(t, dtype=float)
    
    for i, ti in enumerate(t):
        if ti <= EPS:
            result[i] = 1.0
            continue
        
        t_range = np.linspace(EPS, ti, n_steps + 1)
        h_vals = H_approx(t_range, H0=H0, A=A)
        integral = np.trapz(h_vals, t_range)
        result[i] = np.exp(-integral)
    
    return result[0] if scalar_input else result


def clear_caches():
    """DEPRECATED - No longer needed without S(t) caching."""
    pass


def redshift_cosmological(t_emit: float, t_obs: float) -> float:
    """
    DEPRECATED - Cosmological redshift from exponential S(t).
    Use standard z with ΛCDM instead.
    """
    S_emit = global_S(t_emit)
    S_obs = global_S(t_obs)
    return (S_emit / S_obs) - 1.0 if S_obs > 0 else 0.0


def t_from_z(z: float, t_obs: float = 4.35e17, H0=None, A=None, beta_drag=None):
    """
    DEPRECATED - Find emission time from redshift using S(t).
    Use ΛCDM lookback time instead: _cosmo_lcdm.lookback_time(z)
    """
    if z < 0:
        return t_obs
    
    S_obs = global_S(t_obs, H0=H0, A=A, beta_drag=beta_drag)
    target = S_obs * (1 + z)
    
    if target <= 0 or target > 10:
        t_guess = t_obs / ((1 + z) ** 1.5)
        return t_guess
    
    def objective(t_emit):
        if t_emit <= EPS or t_emit >= t_obs:
            return 1e10
        S_emit = global_S(t_emit, H0=H0, A=A, beta_drag=beta_drag)
        return S_emit - target
    
    try:
        t_min = EPS
        t_max = t_obs * 0.999
        result = brentq(objective, t_min, t_max, maxiter=100)
        return result
    except ValueError as e:
        t_guess = t_obs / ((1 + z) ** 1.5)
        return t_guess
'''

# ============================================================================
# End Deprecated Section
# ============================================================================

# ============================================================================
# ESTIF COSMOLOGY (Option A, v6.0) — RETIRED as a cosmology claim (v6.3); historical receipt
# ============================================================================
# Replaces ΩΛ with Ω_tilt(z) derived from the tilt geometry.
# Matter sector (Ωm) retained from ΛCDM.
#
# ESTIF Option A Friedmann equation:
#   H²(z) = H₀² × [Ωm(1+z)³ + Ω_tilt(z)]
#
# Ω_tilt(z) uses the EXACT geometric formula for x(z):
#   x(z) = x₀ × (1+z) × H₀ / H_ΛCDM(z)
#
# This is geometrically derivable — ALPHA_COSMO is NOT a free parameter.
# The power law x ∝ (1+z)^α with α≈0.077–0.089 brackets x(z) from both sides.
#
# HIGH-z CUTOFF (Phase 5.1 — DONE):
#   z_eff = min(z, 2.0) in x(z) calculation.
#   Prevents Ω_tilt divergence at recombination (z~1100).
#   Model is valid at z < 2. CMB extension is future work.
#   All SN, BAO, age results are UNCHANGED by this cutoff.
#
# Six low-redshift tests passed at v6.2 (historical — sector retired v6.3):
#   Pantheon+ SN: 2.08–2.33σ improvement
#   BAO scale:    5/5 redshifts improved
#   Age:          13.63 Gyr (oldest stars ≥ 13.5 Gyr)
#   H₀ tension:  2.7σ → 2.3σ
#   w_eff:       −1.358 (⚠️  falsified by DESI DR2 March 2026 at 3.5σ — cosmology sector under revision)
#   Λ drift:     0.023%/Gyr (EUCLID/LSST approaching)
# ============================================================================

# Planck 2018 cosmological parameters
OMEGA_M      = 0.3111    # matter density (= x₀ to 0.12%)
OMEGA_LAMBDA = 0.6889    # dark energy density (replaced by tilt below)
ALPHA_COSMO  = 0.1036    # reference tilt exponent (within 2σ of geometric range)

_x_0 = (const.c / const.H_0) / 4.4e26   # x₀ = R_H / r_universe today ≈ 0.3107
_Z_EFF_MAX = 2.0                           # High-z cutoff for Ω_tilt validity


def omega_tilt(z):
    """
    ESTIF dark energy density parameter at redshift z (v6.0).
    RETIRED as a cosmology claim (v6.3) — kept as a historical receipt.

    Replaces ΩΛ in the Friedmann equation with a geometrically
    derived quantity from the tilt formula.

    Uses EXACT geometric formula:
        x(z) = x₀ × (1+z) × H₀ / H_ΛCDM(z)

    with a hard cutoff at z_eff = min(z, 2.0) to prevent divergence
    at recombination. Model is validated at z < 2 only.

    At z=0: Ω_tilt = Ω_Λ (matches Planck 2018 exactly)
    At z>0: Ω_tilt evolves with tilt geometry (dark energy was stronger)

    Args:
        z: Redshift (scalar or array)

    Returns:
        Tilt-derived dark energy density (dimensionless)
    """
    z_arr  = np.asarray(z, dtype=float)
    # Apply high-z cutoff (Phase 5.1) — model valid at z < 2
    z_eff  = np.minimum(z_arr, _Z_EFF_MAX)

    # Exact geometric x(z) — uses ΛCDM as ruler to avoid circular dependency
    H_lcdm = const.H_0 * np.sqrt(OMEGA_M*(1+z_eff)**3 + OMEGA_LAMBDA)
    x_z    = _x_0 * (1.0 + z_eff) * const.H_0 / H_lcdm
    x_now  = _x_0

    obs_z   = observable_combined(x_z)
    obs_now = observable_combined(x_now)

    if obs_now <= 0:
        return OMEGA_LAMBDA

    return OMEGA_LAMBDA * (obs_now / obs_z) ** 2


def H_estif(z):
    """
    ESTIF Hubble parameter at redshift z.

    H²(z) = H₀² × [Ωm(1+z)³ + Ω_tilt(z)]

    Matter sector identical to ΛCDM.
    Dark energy replaced by tilt geometry.

    Args:
        z: Redshift (scalar or array)

    Returns:
        H(z) in s⁻¹
    """
    z  = np.asarray(z, dtype=float)
    Hz = const.H_0 * np.sqrt(
        OMEGA_M * (1.0 + z)**3 + omega_tilt(z)
    )
    return Hz


def comoving_distance_estif(z):
    """
    ESTIF comoving distance at redshift z.

    d_C(z) = c × ∫₀ᶻ dz' / H_estif(z')

    Numerically integrated using scipy.

    Args:
        z: Redshift (scalar or array)

    Returns:
        Comoving distance in Mpc
    """
    from scipy.integrate import quad as _quad

    MPC_METRES = 3.085677581e22

    def integrand(zp):
        return const.c / H_estif(zp)

    z = np.atleast_1d(np.asarray(z, dtype=float))
    result = np.zeros_like(z)

    for i, zi in enumerate(z):
        if zi <= 0:
            result[i] = 0.0
        else:
            val, _ = _quad(integrand, 0, zi, limit=100)
            result[i] = val / MPC_METRES   # convert m → Mpc

    return result[0] if result.size == 1 else result


def distance_modulus_estif(z):
    """
    ESTIF distance modulus at redshift z.

    Uses ESTIF comoving distance with standard luminosity distance:
        d_L = (1+z) × d_C

    μ = 5 × log₁₀(d_L / Mpc) + 25

    Args:
        z: Redshift (scalar or array)

    Returns:
        Distance modulus μ in magnitudes
    """
    z   = np.atleast_1d(np.asarray(z, dtype=float))
    d_C = comoving_distance_estif(z)          # Mpc
    d_L = (1.0 + z) * d_C                    # Mpc
    mu  = 5.0 * np.log10(np.maximum(d_L, 1e-10)) + 25.0
    return mu[0] if mu.size == 1 else mu

# ============================================================================
# End ESTIF Cosmology Section
# ============================================================================

# ============================================================================
# EDDY DARK MATTER (v6.0 — March 2026)
# ============================================================================
# Goal 3: No dark matter — the background eddy of the 4D inward flow
# accounts for what we measure as dark matter.
#
# KEY RESULTS (analytically confirmed; claim status v6.4.1: Ωm = x₀ is a
# consistency relation (C2), and the a₀ √3 prefactor is a working form,
# not derived — a₀ is horizon-set):
#
# 1. Ωm = x₀ = R_H/r_universe = 0.3107  ≈  Planck Ωm = 0.3111  (0.12%)
#    x₀ − Ωb = 0.2617  ≈  Ωdm = 0.262  (0.10%)
#
# 2. Virial condition: σ(r)/v_escape(r) = 0.5000 exactly at every scale
#    → Bound orbits are the generic outcome (Earth-Moon condition)
#
# 3. Self-similar Jeans: λ_Jeans(r) = √(2π²/3) × r = 2.565 × r
#    → Every scale marginally unstable simultaneously (true hierarchy)
#
# 4. MOND connection: a₀ = H₀ × c × x₀ / √3 = 1.179×10⁻¹⁰ m/s²
#    MOND empirical: 1.200×10⁻¹⁰ m/s²  →  1.72% agreement
#    The √3 is the 3D projection factor (same as kinetic theory c_s = v/√3)
#
# 5. Multi-scale observable:
#    Observable(r) = √β(x_local) × √β(x_galactic) × √β(x_cosmic)
#    At Earth: local=1.000, galactic=1.000, cosmic=0.830 (dark matter 10⁶× dominant)
#
# What requires N-body simulation (cannot be computed analytically):
#    v_flat = 220 km/s requires internal halo δ ~ 50,000–100,000 × ρ_eddy
#    → Falsifiable prediction for future simulation collaboration
#
# See: tests/test_eddy_dark_matter.py, tests/test_collisionless_eddy.py
#      tests/test_tully_fisher_correction.py, tests/test_mond_sqrt3.py
# ============================================================================

_RHO_CRIT_0 = 3 * const.H_0**2 / (8 * np.pi * const.G)   # Critical density today


def eddy_density_background():
    """
    Background eddy density: ρ_eddy = x₀ × ρ_crit

    This equals Ωm × ρ_crit to within 0.12% — the eddy dark matter identity.
    Not a particle density. The energy density of the cosmic hypersurface spin.

    Returns:
        Background eddy density [kg/m³]
    """
    return _x_0 * _RHO_CRIT_0


def eddy_density_at_z(z):
    """
    Eddy background density at redshift z.

    Scales with volume: ρ_eddy(z) = ρ_eddy_0 × (1+z)³

    At z=10 (galaxy formation epoch): 1331× denser than today.
    Free-fall time at z=10: ~1 Gyr — consistent with observed galaxy formation.

    Args:
        z: Redshift

    Returns:
        Eddy density at redshift z [kg/m³]
    """
    return eddy_density_background() * (1.0 + z)**3


def velocity_dispersion_eddy(r_m):
    """
    Scale-dependent velocity dispersion of the eddy background.

    σ(r) = r × √(2πG × ρ_eddy / 3)

    This is the COLLISIONLESS velocity dispersion — not a fluid sound speed.
    σ grows linearly with r because objects orbit, not collide.

    Key property: σ(r)/v_escape(r) = 0.5000 exactly at every scale.
    → Bound orbits (Earth-Moon condition) are generic — not mergers, not flybys.

    Args:
        r_m: Radius [m]

    Returns:
        Velocity dispersion [m/s]
    """
    rho = eddy_density_background()
    return r_m * np.sqrt(2 * np.pi * const.G * rho / 3)


def jeans_length_eddy(r_m):
    """
    Jeans length at scale r from the eddy background (collisionless).

    λ_Jeans(r) = √(2π²/3) × r = 2.5651 × r

    This universal constant (√(2π²/3)) means every scale is marginally
    unstable simultaneously — true hierarchical fragmentation from
    first principles, without tuning.

    Args:
        r_m: Scale [m]

    Returns:
        Jeans length [m]
    """
    return np.sqrt(2 * np.pi**2 / 3) * r_m


def a0_mond_estif():
    """
    MOND critical acceleration derived from ESTIF geometry.

    a₀ = H₀ × c × x₀ / √3

    The √3 comes from isotropic 3D projection of the 4D eddy kinetic energy:
    each spatial dimension receives 1/3 of the total energy → v_1D = v_4D/√3.

    Same factor as kinetic theory (c_s = v_rms/√3) and Jeans criterion.

    Agreement with MOND empirical value (1.2×10⁻¹⁰ m/s²): 1.72%

    This is a PREDICTION, not a fit. MOND may be the galactic weak-field
    limit of the ESTIF cosmic eddy — as Newton is the weak-field limit of GR.

    Returns:
        ESTIF-derived MOND acceleration [m/s²]
    """
    return const.H_0 * const.c * _x_0 / np.sqrt(3)


def v_flat_mond_estif(M):
    """
    Flat rotation velocity from ESTIF MOND limit.

    v_flat⁴ = G × M × a₀    (Tully-Fisher relation, M^(1/4) scaling)

    Uses a₀ = H₀ × c × x₀ / √3 derived from geometry.

    Args:
        M: Galaxy mass [kg]

    Returns:
        Flat rotation velocity [m/s]
    """
    a0 = a0_mond_estif()
    return (const.G * M * a0)**0.25


def multi_scale_observable(r_m, M_local, M_host=None, r_in_host=None):
    """
    Three-level ESTIF observable at position r from a local mass.

    Observable(r) = √β(x_local) × √β(x_galactic) × √β(x_cosmic)

    where:
        x_local    = Rs_local / r          (local mass eddy)
        x_galactic = Rs_host / r_in_host   (host galaxy eddy, optional)
        x_cosmic   = x₀ = R_H/r_universe  (cosmic background = Ωm)

    At Earth (r=1AU, M_sun):
        x_local ≈ 2×10⁻⁸ → obs = 1.0000000
        x_gal   ≈ 3×10⁻⁷ → obs = 1.0000000
        x_cosmic = 0.311 → obs = 0.8300
    Cosmic term dominates by 10⁶×.

    Args:
        r_m: Distance from local mass [m]
        M_local: Local mass (e.g. Sun, black hole) [kg]
        M_host: Host galaxy mass [kg] (optional)
        r_in_host: Distance in host galaxy [m] (optional)

    Returns:
        Combined observable (dimensionless, 0 to 1)
    """
    Rs_local = 2 * const.G * M_local / const.c**2
    x_local  = Rs_local / r_m
    obs_local = observable_combined(x_local)

    obs_galactic = 1.0
    if M_host is not None and r_in_host is not None:
        Rs_host = 2 * const.G * M_host / const.c**2
        x_gal   = Rs_host / r_in_host
        obs_galactic = observable_combined(x_gal)

    obs_cosmic = observable_combined(_x_0)

    return obs_local * obs_galactic * obs_cosmic

# ============================================================================
# End Eddy Dark Matter Section
# ============================================================================

# ------------------------------
# Distance Functions (Now Using ΛCDM)
# ------------------------------

def distance_modulus_lcdm(z):
    """
    ⚠️ WORK IN PROGRESS - Needs validation against JWST data

    Distance modulus using standard ΛCDM cosmology.
    
    ESTIF-Gravity fork: No modifications to cosmological distances.
    All cosmology follows standard ΛCDM.
    
    Args:
        z: Redshift (scalar or array)
    
    Returns:
        Distance modulus μ in magnitudes
    """
    z = np.atleast_1d(z)
    scalar_input = z.ndim == 0 or len(z) == 1
    
    # Use ΛCDM luminosity distance
    d_L = luminosity_distance(z)
    
    # Distance modulus: μ = 5 log₁₀(d_L/Mpc) + 25
    mu = 5 * np.log10(d_L) + 25
    
    return mu[0] if scalar_input else mu


# Alias for compatibility
distance_modulus_estif_numerical = distance_modulus_lcdm


def d_m(z):
    """
    Comoving distance for BAO/CMB fits.
    Uses standard ΛCDM.
    """
    return comoving_distance(z)


def r_d_approx(z=1100):
    """
    Sound horizon at drag epoch.
    Use standard ΛCDM value since we don't modify cosmology.
    """
    return 147.0  # Mpc, from Planck 2018


# ------------------------------
# Gravitational Wave Functions
# ------------------------------

def gw_damping_delay(r, M, t=None):
    """
    ⚠️ WORK IN PROGRESS - Needs validation against JWST data

    GW propagation delay from 4D friction drag.
    
    Uses same scaling principle as lensing:
    - Gravitational waves experience drag near massive objects
    - Delay proportional to β × (R_s/r)
    - Delay time ~ (light-crossing time) × (friction factor)
    
    This predicts measurable timing delays in LIGO/LISA observations.
    
    Args:
        r: Characteristic radius (m) - use R_s for merger events
        M: Binary total mass (kg)
        t: Time (kept for compatibility, unused)
    
    Returns:
        Time delay in seconds
        
    Example:
        For GW150914 (65 M_sun binary at merger):
        M_binary = 65 * const.M_sun
        rs = schwarzschild_radius(M_binary)
        delay = gw_damping_delay(rs, M_binary)
        # With β=0.05: delay ≈ 3×10⁻⁵ s (LISA-detectable range)
    """
    # Schwarzschild radius
    rs = 2 * const.G * M / const.c**2
    
    # At merger, use R_s as characteristic scale
    r_isco = 3 * rs
    if r == 0 or r < r_isco:
        r = r_isco
    
    # Base timescale: light-crossing time of Schwarzschild radius
    tau_base = rs / const.c
    
    # Friction correction factor (same form as lensing)
    friction_factor = const.BETA_DRAG * (rs / r)
    
    # Total delay: base timescale × friction factor
    # For r = R_s: delay = (R_s/c) × β
    delay = tau_base * friction_factor
    
    return delay


def galaxy_drag_asymmetry(z, M_galaxy, r, H_func=None):
    """
    ⚠️ WORK IN PROGRESS - Needs validation against JWST data

    Galaxy rotation asymmetry from 4D friction drag.
    
    Uses same scaling principle as lensing and GW:
    - Friction creates "fossil eddy" patterns in galaxy rotation
    - Asymmetry proportional to β × (R_s/r)
    - Stronger at higher redshift (galaxies forming in denser 4D flow)
    
    This predicts observable morphological asymmetries in JWST high-z galaxies.
    
    Args:
        z: Redshift of galaxy
        M_galaxy: Galaxy stellar mass (kg)
        r: Galactic radius (m) - typically half-light radius
        H_func: Ignored (kept for compatibility)
    
    Returns:
        Asymmetry as percentage
        
    Example:
        For 10^11 M_sun galaxy at z=3 with r=3 kpc:
        M = 1e11 * const.M_sun
        r = 3e3 * 3.086e16  # 3 kpc in meters
        asym = galaxy_drag_asymmetry(3, M, r)
        # With β=0.05: asym ≈ 0.015% (below JWST precision)
    """
    # Schwarzschild radius for galaxy
    rs_galaxy = 2 * const.G * M_galaxy / const.c**2
    
    # Friction asymmetry (same scaling as lensing)
    # The factor of 2 in lensing came from the deflection geometry
    # For rotation asymmetry, we use direct scaling
    friction_factor = const.BETA_DRAG * (rs_galaxy / r)
    
    # Convert to percentage
    asymmetry_percent = friction_factor * 100
    
    # Optional: add redshift dependence if friction stronger at high-z
    # For now, keep it simple and consistent with lensing
    
    return asymmetry_percent

# ------------------------------
# Geodesic and Metric Classes
# ------------------------------

class Geodesic:
    """
    Geodesic equations with friction-drag corrections.
    
    For weak fields: Matches GR
    For strong fields: Small deviations from local drag
    """
    
    def acceleration(self, position, M, t):
        """
        Acceleration from flow field with friction corrections.
        
        Args:
            position: Position vector (m)
            M: Central mass (kg)
            t: Time (s)
        
        Returns:
            Acceleration vector (m/s²)
        """
        position = np.atleast_2d(position)
        r = np.linalg.norm(position, axis=-1, keepdims=True)
        r = np.where(r < 1e-10, 1e-10, r)
        r_hat = position / r
        
        # Use cosmic drag for time-dependent term (weak correction)
        flow_velocity = const.H_0 * r  # Simplified to H_0
        drag_factor = 1 + friction_drag(t) * (const.G * M / (r * const.c**2))
        drag_factor = np.clip(drag_factor, 0.1, 10.0)
        flow_velocity = np.clip(flow_velocity, -1e10, 1e10)
        
        acceleration = -flow_velocity * r_hat * drag_factor
        return acceleration.squeeze() if position.ndim == 1 else acceleration

    def geodesic_derivatives(self, state, M, t):
        """
        Derivatives for geodesic equation with friction corrections.
        
        Args:
            state: [x, y, vx, vy] or array of states
            M: Central mass (kg)
            t: Time (s)
        
        Returns:
            [vx, vy, ax, ay] derivatives
        """
        if state.ndim == 1:
            x, y = state[:2]
            r = np.sqrt(x**2 + y**2)
            pos = state[:2]
        else:
            x, y = state[:,0], state[:,1]
            r = np.sqrt(x**2 + y**2)
            pos = state[:,:2]
        
        r = np.maximum(r, 1e-10)
        rs = 2 * const.G * M / const.c**2
        
        # GR acceleration with post-Newtonian correction
        accel = -(const.G * M / r**2) * (1 + rs / r)
        direction = pos / r[..., None] if state.ndim > 1 else pos / r
        
        derivatives = np.zeros_like(state)
        if state.ndim == 1:
            derivatives[:2] = state[2:]
            derivatives[2:] = accel * direction
        else:
            derivatives[:,:2] = state[:,2:]
            derivatives[:,2:] = accel[:, None] * direction
        
        return derivatives


class Metric:
    """
    Spacetime metric with friction corrections.
    
    For weak fields: g_μν ≈ Schwarzschild metric
    For strong fields: Small corrections from local drag
    """
    
    def __init__(self, r, M, t=0):
        """
        Initialize metric components.
        
        Args:
            r: Radial distance (m)
            M: Central mass (kg)
            t: Time (s) - used for time-dependent corrections
        """
        rs_term = (const.G * M) / (r * const.c**2)
        
        # Include small friction correction
        phi = 1 - 2 * rs_term + friction_drag(t) * rs_term
        
        time_factor = np.sqrt(phi) if phi > 0 else np.nan
        self.g_tt = -(time_factor**2) if not np.isnan(time_factor) else np.nan
        self.g_rr = 1 / (time_factor**2) if not np.isnan(time_factor) else np.nan


# ------------------------------
# Utility Functions
# ------------------------------

def rotation_curve(r_array, M, t, dt=1e-6):
    """
    Rotation curve with friction effects.
    
    Note: For ESTIF-Gravity, this is primarily for consistency checking.
    Dark matter explanation not pursued in gravity-only fork.
    
    Args:
        r_array: Array of radii (m)
        M: Central mass (kg)
        t: Time (s)
        dt: Time step for precession (s)
    
    Returns:
        Velocity array (m/s)
    """
    r_array = np.atleast_1d(r_array)
    drag_factor = 1 + friction_drag(t) * (const.G * M / (r_array * const.c**2))
    precession_adjust = np.exp(-dt / (t + EPS))
    v = np.sqrt(const.G * M / r_array) * drag_factor * precession_adjust
    return v


def schwarzschild_radius(mass):
    """
    Calculate Schwarzschild radius for given mass.
    
    Args:
        mass: Mass (kg)
    
    Returns:
        Schwarzschild radius (m)
    """
    return 2 * const.G * mass / const.c**2


def escape_velocity(mass, radius):
    """
    Calculate escape velocity from surface.
    
    Args:
        mass: Mass (kg)
        radius: Radius (m)
    
    Returns:
        Escape velocity (m/s)
    """
    mass = np.atleast_1d(mass)
    radius = np.atleast_1d(radius)
    return np.sqrt(2 * const.G * mass / radius)


def check_gr_limit(r, M, t, tol=0.01):
    """
    Check weak-field GR limit for lensing deviation.
    
    Ensures ESTIF-Gravity matches GR within tolerance in weak fields.
    
    Args:
        r: Distance (m)
        M: Mass (kg)
        t: Time (s)
        tol: Tolerance (default 1%)
    
    Returns:
        (bool, str): (passes_test, warning_message)
    """
    r = np.atleast_1d(r)
    
    # GR baseline
    lensing_base = (4 * const.G * M) / (const.c**2 * r)
    theta_gr = lensing_base
    
    # ESTIF with friction correction
    theta_estif = lensing_base * (1 + friction_drag(t) / const.H_0)
    
    # Calculate deviation
    dev = np.abs(theta_estif / theta_gr - 1)
    mask = dev > tol
    warning_msg = ""
    
    if np.any(mask):
        max_dev = np.max(dev[mask])
        warning_msg = f"Warning: Max dev {max_dev:.2%} > tol {tol:.2%}; applying decay"
        
        # Apply exponential suppression for very weak fields
        correction = np.exp(-const.G * M / (r * const.c**2))
        theta_estif = theta_gr * (1 + (friction_drag(t) / const.H_0) * correction)
        dev = np.abs(theta_estif / theta_gr - 1)
    
    return np.all(dev < tol), warning_msg


def unique_lensing_signature(r, M, t=None):
    """
    Modified lensing from 4D friction drag.
    
    Implements the lensing equation derived from ESTIF-Gravity:
    θ_ESTIF = θ_GR × (1 + β × R_s / (2b))
    
    This is a direct "shadow" of 4D friction - testable via EHT observations.
    
    Args:
        r: Impact parameter (distance from lens) (m)
        M: Mass of lensing object (kg)
        t: Time (kept for compatibility, unused)
    
    Returns:
        Deflection angle in radians
        
    Example:
        For M87* at photon sphere (1.5 R_s):
        M_m87 = 6.5e9 * const.M_sun
        rs = schwarzschild_radius(M_m87)
        r_photon = 1.5 * rs
        theta = unique_lensing_signature(r_photon, M_m87)
        theta_gr = 4*const.G*M_m87 / (const.c**2 * r_photon)
        deviation = (theta/theta_gr - 1) * 100
        # With β=0.05: deviation ≈ 1.67% at photon sphere
    """
    # GR baseline deflection
    theta_gr = (4 * const.G * M) / (const.c**2 * r)
    
    # Schwarzschild radius
    rs = 2 * const.G * M / const.c**2
    
    # ESTIF correction from 4D friction
    # This is the "shadow" - the 3D observable effect of 4D drag
    correction_factor = 1 + const.BETA_DRAG * (rs / (2 * r))
    
    return theta_gr * correction_factor


# ------------------------------
# Test Functions
# ------------------------------

def test_scale_perception(z_test=1.0):
    """
    Test redshift consistency.
    
    For ESTIF-Gravity: Just verifies ΛCDM works correctly.
    No longer testing exponential S(t).
    """
    try:
        # Simple ΛCDM check
        a_test = scale_factor_lcdm(z_test)
        z_recovered = 1.0/a_test - 1.0
        assert np.isclose(z_recovered, z_test, rtol=0.01), "Scale factor mismatch"
        print(f"✓ ΛCDM consistency check passed at z={z_test}")
    except Exception as e:
        print(f"Warning: Scale test failed: {e}")


def test_friction_scaling(mass1=1.0, mass2=2.0, r=1e10):
    """
    Test that local drag scales with mass (stone analogy).
    
    Larger mass → higher density → stronger drag
    """
    drag1 = friction_drag_local(mass1 * const.M_sun, r)
    drag2 = friction_drag_local(mass2 * const.M_sun, r)
    
    # Should scale linearly with mass (same radius)
    ratio = drag2 / drag1
    expected_ratio = mass2 / mass1
    
    assert np.isclose(ratio, expected_ratio, rtol=0.01), \
        f"Mass-scaled friction mismatch: {ratio:.3f} vs {expected_ratio:.3f}"
    
    print(f"✓ Friction scaling test passed: {mass2}M/{mass1}M = {ratio:.3f}x drag")


# ------------------------------
# Main Test Block
# ------------------------------

if __name__ == "__main__":
    print("="*70)
    print("ESTIF-GRAVITY MODEL - Basic Tests")
    print("="*70)
    
    try:
        # Test 1: ΛCDM functions
        print("\n1. Testing ΛCDM cosmology functions:")
        z_test = 0.5
        d_L = luminosity_distance(z_test)
        mu = distance_modulus_lcdm(z_test)
        print(f"   z={z_test}: d_L = {d_L:.1f} Mpc, μ = {mu:.2f} mag")
        print(f"   Expected: d_L ≈ 2700 Mpc, μ ≈ 42.2 mag")
        
        if 2500 < d_L < 2900 and 41.5 < mu < 42.5:
            print("   ✓ ΛCDM functions working correctly")
        else:
            print("   ⚠️  Values outside expected range")
        
        # Test 2: Friction scaling
        print("\n2. Testing friction drag scaling:")
        test_friction_scaling(mass1=1.0, mass2=2.0, r=1e10)
        
        # Test 3: Local vs cosmic drag comparison
        print("\n3. Comparing local vs cosmic drag:")
        t_now = 4.35e17  # Current age
        M_sun_mass = const.M_sun
        r_sun = const.R_sun
        
        drag_cosmic = friction_drag(t_now)
        drag_local = friction_drag_local(M_sun_mass, r_sun)
        
        print(f"   Cosmic drag (t=now): {drag_cosmic:.3e}")
        print(f"   Local drag (Sun surface): {drag_local:.3e}")
        print(f"   Ratio (local/cosmic): {drag_local/drag_cosmic:.3e}")
        print(f"   ✓ Local drag >> cosmic (as expected for predictions)")
        
        # Test 4: Lensing prediction
        print("\n4. Testing lensing prediction:")
        r_test = 5 * schwarzschild_radius(M_sun_mass)
        theta_estif = unique_lensing_signature(r_test, M_sun_mass)
        theta_gr = (4 * const.G * M_sun_mass) / (const.c**2 * r_test)
        deviation = (theta_estif / theta_gr - 1) * 100
        
        print(f"   At r = 5 R_s from Sun:")
        print(f"   GR deflection: {theta_gr:.3e} rad")
        print(f"   ESTIF deflection: {theta_estif:.3e} rad")
        print(f"   Deviation: {deviation:.4f}%")
        print(f"   ⚠️  Note: Magnitude pending validation")
        
        # Test 5: Weak-field GR compliance
        print("\n5. Testing weak-field GR limit:")
        r_large = 1e12  # 1 Tm (very far from Sun)
        passes, msg = check_gr_limit(r_large, M_sun_mass, t_now, tol=0.01)
        print(f"   At r = {r_large:.0e} m:")
        print(f"   Passes <1% test: {passes}")
        if msg:
            print(f"   {msg}")
        
        print("\n" + "="*70)
        print("Basic tests complete!")
        print("="*70)
        
        print("\n📋 Summary:")
        print("   ✓ ΛCDM cosmology: Working")
        print("   ✓ Friction functions: Implemented")
        print("   ✓ Weak-field limit: GR compliance")
        print("   ⚠️  Strong-field predictions: Pending validation")
        print("\nNext steps:")
        print("   1. Run estif_ec_gr_run_simulation.py for full test suite")
        print("   2. Compare predictions to EHT/LIGO/JWST data")
        print("   3. Refine prediction magnitudes based on observations")
        
    except Exception as e:
        print(f"\n❌ Error during testing: {e}")
        import traceback
        traceback.print_exc()
